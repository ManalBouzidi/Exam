package com.controle.course.service;

import com.controle.course.models.StudentsOfaCourse;

public interface StudentsOfCourse {
    public StudentsOfaCourse getStudentsOfaCourse(int courseId);
}
